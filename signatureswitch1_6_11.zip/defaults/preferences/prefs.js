pref("extensions.{2ab1b709-ba03-4361-abf9-c50b964ff75d}.description", "chrome://signatureswitch/locale/signatureswitch.description");
